const characters = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9","~","`","!","@","#","$","%","^","&","*","(",")","_","-","+","=","{","[","}","]",",","|",":",";","<",">",".","?",
"/"];

let password1El = document.getElementById('password-el-1')
let password2El = document.getElementById('password-el-2')
let outputEl = document.getElementById('password-length')

function generatePasswords(){
    let password1 = getPassword()
    let password2 = getPassword()
    
    console.log("Password length required: " + outputEl.textContent)

    console.log("Password-1: " + password1)
    console.log(password1.length)
    console.log("Password-2: " + password2)
    console.log(password2.length)

    password1El.textContent = password1
    password2El.textContent = password2
}

function getPassword()
{
    let password = ""
    for (let i=0; i<outputEl.textContent; i++)
    {
        password += characters[Math.floor(Math.random() * characters.length)]
    }
    return password
}

function copyContent(elId){
    let copyEl = document.getElementById(elId)
       
    navigator.clipboard.writeText(copyEl.textContent)
}




